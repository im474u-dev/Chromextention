chrome.action.onClicked.addListener(t=>{const e=chrome.runtime.getURL("index.html");chrome.tabs.create({url:e})});
